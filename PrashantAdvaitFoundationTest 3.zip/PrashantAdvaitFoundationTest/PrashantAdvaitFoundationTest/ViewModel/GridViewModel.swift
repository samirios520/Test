//
//  GridViewModel.swift
//  PrashantAdvaitFoundationTest
//
//  Created by MacBook on 25/04/24.
//

import Foundation


class GridViewModel {
    

    var arrImage : [GridCollectionViewCellModel] = []
    
    
    func apiGetResponse( completion: @escaping (Bool) -> Void){
        APIManager.shared.getHttpRequest(urlString: Constant.APIURL) { result in
            switch result {
            case .success(let data):
                print("Received data:", result)
                self.arrImage = data.map{GridCollectionViewCellModel($0.thumbnail)}
                completion(true)
            case .failure(let error):
                // Handle error
                completion(false)
                print("Error:", error.localizedDescription)
            }
        }
    }
    
    


}

class GridCollectionViewCellModel {
    var domain: String?
    var basePath: String?
    var key: String?
    
    init(_ thumbnail: Thumbnail) {
        domain = thumbnail.domain
        basePath = thumbnail.basePath
        key = thumbnail.key
    }
}
