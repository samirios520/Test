//
//  Constant.swift
//  PrashantAdvaitFoundationTest
//
//  Created by MacBook on 25/04/24.
//

import Foundation


struct Constant {
    
    static let APIURL = "https://acharyaprashant.org/api/v2/content/misc/media-coverages?limit=100"
    
}
