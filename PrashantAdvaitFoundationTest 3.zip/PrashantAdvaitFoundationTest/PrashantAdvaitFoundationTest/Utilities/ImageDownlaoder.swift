import UIKit

class ImageDownloader {

    static let shared = ImageDownloader()
    
    private let urlCache = URLCache.shared
    private let memoryCache = NSCache<NSString, UIImage>()
    private let imageLoader = URLSession.shared
    
    // Function to load image with URL
    func loadImage(with url: URL, targetSize: CGSize, completion: @escaping (UIImage?) -> Void) {
        // Check if image is available in memory cache
        if let cachedImage = memoryCache.object(forKey: url.absoluteString as NSString) {
            completion(cachedImage)
            return
        }
        
        // Check if image is available in disk cache
        if let cachedResponse = urlCache.cachedResponse(for: URLRequest(url: url)),
           let image = UIImage(data: cachedResponse.data),
           let resizedImage = resizeImage(image: image, targetSize: targetSize) {
            memoryCache.setObject(resizedImage, forKey: url.absoluteString as NSString)
            completion(resizedImage)
            return
        }
        
        // If image is not found in caches, download it
        let task = imageLoader.dataTask(with: url) { [weak self] (data, response, error) in
            guard let self = self, let data = data, let image = UIImage(data: data), error == nil else {
                completion(nil)
                return
            }
            if let resizedImage = self.resizeImage(image: image, targetSize: targetSize) {
                self.memoryCache.setObject(resizedImage, forKey: url.absoluteString as NSString)
                completion(resizedImage)
            } else {
                completion(nil)
            }
        }
        task.resume()
    }
    
    // Function to resize image to a specified target size
    private func resizeImage(image: UIImage, targetSize: CGSize) -> UIImage? {
        let size = image.size

        let widthRatio  = targetSize.width  / size.width
        let heightRatio = targetSize.height / size.height

        var newSize: CGSize
        if widthRatio > heightRatio {
            newSize = CGSize(width: size.width * heightRatio, height: size.height * heightRatio)
        } else {
            newSize = CGSize(width: size.width * widthRatio,  height: size.height * widthRatio)
        }

        let rect = CGRect(origin: .zero, size: newSize)
        UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
        image.draw(in: rect)
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()

        return newImage
    }
}

