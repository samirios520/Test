//
//  APIManager.swift
//  PrashantAdvaitFoundationTest
//
//  Created by MacBook on 25/04/24.
//

import Foundation



enum NetworkError: Error {
    case invalidURL
    case invalidResponse
    case noData
    // Add more cases as needed
}

class APIManager {
    
    static let shared = APIManager()
    
    private init() {}
    
    
    func getHttpRequest(urlString: String, completion: @escaping (Result<[GridModel], Error>) -> Void) {
        guard let url = URL(string: urlString) else {
            completion(.failure(NetworkError.invalidURL))
            return
        }

        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
                completion(.failure(NetworkError.invalidResponse))
                return
            }
            
            guard let data = data else {
                completion(.failure(NetworkError.noData))
                return
            }
            
            let decoder = JSONDecoder()
            do {
                let result = try decoder.decode([GridModel].self, from: data)
                completion(.success(result))
            } catch let error {
                print("error ocurred while decoding",error.localizedDescription)
            }

            
        }.resume()
    }

}
