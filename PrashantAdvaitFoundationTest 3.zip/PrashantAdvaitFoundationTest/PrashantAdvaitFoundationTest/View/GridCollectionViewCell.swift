//
//  GridCollectionViewCell.swift
//  PrashantAdvaitFoundationTest
//
//  Created by MacBook on 25/04/24.
//

import UIKit

class GridCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var image: UIImageView!
    
    var obj: GridCollectionViewCellModel! {
        didSet {
            let targetSize = CGSize(width: 100, height: 100)
            if let domain = obj.domain, let basePath = obj.basePath, let key = obj.key {
                let urlString = domain + "/" + basePath + "/0/" + key
                print("Url",urlString)
                
                DispatchQueue.global().async {
                    
                    if let url = URL(string: urlString) {
                        ImageDownloader.shared.loadImage(with: url,targetSize: targetSize) { downloadedImage in
                            // Update the image view in the cell
                            DispatchQueue.main.async {
                                self.image.image = downloadedImage
                            }
                           
                        }
                    } else {
                        print("Invalid URL: \(urlString)")
                    }

                    
                }
                
                
                
            }
            
        }
    }
}
