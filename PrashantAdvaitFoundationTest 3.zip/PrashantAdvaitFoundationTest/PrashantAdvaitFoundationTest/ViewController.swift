//
//  ViewController.swift
//  PrashantAdvaitFoundationTest
//
//  Created by MacBook on 25/04/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var GridCollectionView: UICollectionView!
    
    var viewModel = GridViewModel()
    
   
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let layout = UICollectionViewFlowLayout()
              layout.scrollDirection = .vertical
              layout.minimumInteritemSpacing = 10
              layout.minimumLineSpacing = 10
        GridCollectionView.collectionViewLayout = layout
        
        if Reachability.isConnectedToNetwork() {
            // There is an active network connection, proceed with the API call
            // Make your API call here
            viewModel.apiGetResponse() { res in
                if res {
                    DispatchQueue.main.async {
                        self.GridCollectionView.delegate = self
                        self.GridCollectionView.dataSource = self
                        self.GridCollectionView.reloadData()
                    }
                    
                } else {
                    let alertController = UIAlertController(title: "Alert", message: "No data found", preferredStyle: .alert)
                    let okAction = UIAlertAction(title: "OK", style: .default) { (action:UIAlertAction!) in
                        // Code to execute when OK is tapped
                        print("OK")
                    }
                    alertController.addAction(okAction)
                    self.present(alertController, animated: true, completion:nil)
                }
                
            }

        } else {
            // There is no active network connection, show an alert or handle accordingly
                    print("No internet connection")
            // Create UIAlertController
                    let alertController = UIAlertController(title: "Alert", message: "No Internet", preferredStyle: .alert)
                    let okAction = UIAlertAction(title: "OK", style: .default) { (action:UIAlertAction!) in
                        // Code to execute when OK is tapped
                        print("OK")
                    }
                    alertController.addAction(okAction)
                    self.present(alertController, animated: true, completion:nil)

        }
        
                // Do any additional setup after loading the view.
    }
    
    
    
    
    


}

extension ViewController: UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    // MARK: - UICollectionViewDataSource
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // Return the number of items in your collection view
        return viewModel.arrImage.count // Example number of items
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "GridCollectionViewCell", for: indexPath) as! GridCollectionViewCell
        let model = self.viewModel.arrImage[indexPath.row]
        cell.obj = model
        
        return cell
    }
    
    // MARK: - UICollectionViewDelegateFlowLayout
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let numberOfColumns: CGFloat = 3 // Number of columns you want
        let padding: CGFloat = 10 * (numberOfColumns - 1) // Total padding between cells
        let collectionViewWidth = collectionView.frame.size.width
        let availableWidth = collectionViewWidth - padding
        let itemWidth = availableWidth / numberOfColumns
        return CGSize(width: itemWidth, height: itemWidth)
    }


    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 10 // Adjust spacing between cells horizontally
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 10 // Adjust spacing between cells vertically
    }

    
}
